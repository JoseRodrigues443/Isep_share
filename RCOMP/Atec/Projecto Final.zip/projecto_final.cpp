#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
#include <windows.h>
using namespace std;
//Invoca:
void menu_principal();void encriptar();void info_menu();void jogos_menu();void contacts();void apps_menu();void bloco();void bots();
void gotoxy(int column, int line)	//para funcionar os joguinhos
{
	COORD coord;
	coord.X = column;
	coord.Y = line;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
void main()
{
	menu_principal();
}
//________________________Menu Principal
void menu_principal()
{
	system("CLS");
	char x;
	cout << "Bem vindo!!!" << endl << "1- APPS | 2- Jogos | 3- Info | 0- Sair |" << endl;
	cin >> x;
	if (x == '1')
	{
		apps_menu(); 
	}
	else if (x == '2')
	{
		jogos_menu();
	}
	else if (x == '3')
	{
		info_menu();
	}
	else if (x == '0')
	{
		system("pause");	//desliga
	}
	else
	{
		system("CLS");
		menu_principal();
	}

}
//________________________APPS
void apps_menu()
{
	char x;
	system("CLS");
	cout << "Apps" << endl << "1- Bloco de Notas | 2- Contactos | 3- Encriptar | 0- Voltar ao menu inicial |" << endl;
	cin >> x;
	if (x == '1')
	{
		bloco();
	}
	else if (x == '2')
	{
		contacts();
	}
	else if (x == '3')
	{
		encriptar();
	}
	else if (x == '0')
	{
		menu_principal();
	}
	else
	{
		system("CLS");
		apps_menu();
	}
}
//________________________Jogos
void jogos_menu()
{
	char x;
	cout << "Jogos" << endl << "1- Tron | 2- Bots  | 0- Voltar ao menu inicial |" << endl;
	cin >> x;
	if (x == '1')
	{
		//tron();
	}
	else if (x == '2')
	{
		bots();
	}
	else if (x == '0')
	{
		menu_principal();
	}
	else
	{
		system("CLS");
		jogos_menu();
	}
}
//________________________Info
void info_menu()
{
	char x;
	string leitura;
	cout << "Info" << endl << "1- Codigo fonte | 2- Autoria | 3- GPL | 0- Voltar ao menu inicial |" << endl;
	cin >> x;
	if (x == '1')
	{
		system("cls");
		ifstream codig("codig.txt");
		while (codig >> leitura)
		{
			cout << leitura << endl;
		}
		cout << "\n\n\nFIM DO CÓDIGO";
		codig.close();
		cin.get();
		info_menu();
	}
	else if (x == '2')
	{
		system("CLS");
		cout << "Programa criado por José Rodrigues" << endl << "Na ATEC, sobre a alçada do Prof. Ricardo Sousa, na turma GRSIP 10.14" << endl;
	}
	else if (x == '3')
	{
		system("cls");
		ifstream gpl("gpl.txt");
		while (gpl >> leitura)
		{
			cout << leitura << endl;
		}
		cout << "\n\n\nFIM DA GPL";
		gpl.close();
		cin.get();
		info_menu();
	}
	else if (x == '0')
	{
		menu_principal();
	}
	else
	{
		system("CLS");
		info_menu();
	}
}
//________________________
//________________________
//________________________
//________________________
//________________________Mini Apps:
//________________________Bloco
void bloco()
{
	char x;
	string insert, ler;
	system("CLS");
	cout << "Bloco de Notas \n1- Ler  | 2- Escrever | 0- Sair para o menu inicial" << endl << endl;
	cin >> x;
	if (x == '1')	//ler
	{
		ifstream bloco_ler("bloco.txt");
		while (bloco_ler >> ler);  //enqnt n chegar ao fim passa a linha para a variavel ler, e imprime linha por linha
		{
			cout << ler << endl; //imprime variavel
		}
		cout << "\n\n\n\nFIM DE FICHEIRO\n";
		cin.get();cin.get();
		bloco_ler.close();
		bloco();
	}
	else if (x == '2')	//escreve
	{
		cout << "Insira os valores a acrecentar ao bloco de notas (*para terminar a insercao)" << endl << endl;
		ofstream bloco_esq("bloco.txt");
		getline(cin, insert, '*');
		bloco_esq << insert;
		cout << "Foi inserido" << endl;
		bloco_esq.close();
		bloco();   //volta ao menu		
	}
	else if (x == '0')
	{
		menu_principal();   //volta ao inicio
	}
	else
	{
		bloco();
	}
}
/*________________________Contactos      esta é dificil!!!!
Telefone é gravado depois do !		    	      ex:    !910231443(não esta na forma 910 231 443 porque pode haver numeros estrangeiros)
Nome é gravado apos			              ex:    <Alfredo Almerindo Zulmiro
Morada é gravado apos $		         	      ex:    $Avenida da Costinha
no file ficaria:
!910231443
<Alfredo Almerindo Zulmiro
$Avenida da Costinha
__________________________*/
void contacts()
{
	char x, y;
	int size, i, count = 0, check = 0;
	system("CLS");
	string contact, ler_c, procura;
	cout << "Contactos \n 1- Novo Contacto  | 2- Ver todos os contactos| 3- Procurar contacto | 0- Sair para o menu inicial" << endl << endl;
	cin >> x;

	if (x == '1')
	{
		ofstream insere("contactos.txt");
		cout << "Insira um numero de telefone (* para sair)" << endl;
		getline(cin, contact, '*');
		insere << "!" << contact << endl;	   //!910231443  enter
		cout << "Insira o nome (* para sair)" << endl;
		getline(cin, contact, '*');
		insere << "<" << contact << endl;	   //<Alfredo Almerindo Zulmiro enter
		cout << "Insira a morada (* para sair)" << endl;
		getline(cin, contact, '*');
		insere << "$" << contact << endl;	   //$Avenida da Costinha enter	
		insere.close();
		contacts();	//volta ao inicio
	}
	else if (x == '2')		//ler
	{
		ifstream cont_ler("contactos.txt");	//abre file para a opçao 2
		while (cont_ler >> ler_c) //lê palavra por palavra
		{
			if (ler_c[0] == '!') //é o numero de telefone
			{
				count++;  //numero do contacto, o contacto começa sempre pelo numero
				cout << "\n\n||" << count << "  || Telefone:  ";
				size = sizeof(ler_c);		//tamanho do numero de telefone		ex: !910 231 443	==>10 caracetres...
				for (i = 1/*9*/; i <= size - 1/*3*/; i++)
				{
					cout << ler_c[i];
				}
			}
			else if (ler_c[0] == '<')	//é o nome (primeira palavra do nome)
			{
				size = sizeof(ler_c);
				cout << "	||	Nome:	";
				for (i = 1; i <= size - 1; i++)
				{
					cout << ler_c[i];
				}
			}
			else if (ler_c[0] == '$')	//é a morada (primeira palavra)
			{
				cout << "	||	Morada:	";
				size = sizeof(ler_c);
				for (i = 1; i <= size - 1; i++)
				{
					cout << ler_c[i];
				}
			}
			else		//nomes secundarios ou moradas resto
			{
				cout << " " << ler_c;
			}
		}
		cout << "\n\n\n\n\n\nFIM DOS CONTACTOS" << endl;
		cont_ler.close();
		cin.get();
		contacts();
	}
	else if (x == '3')	//Procurar contacto
	{
		cout << "Procurar: 1-Telefone		2-Nome		3-Morada" << endl << endl;
		cin >> y;
			if (y == '1')
			{
				cout << "Insira o telefone a procurar (* para sair):  ";
				getline(cin, procura, '*');
				procura = "!" + procura;
					while (cont_ler >> ler_c) //lê palavra por palavra
					{
						if (ler_c[0] == '!') //é o numero de telefone
						{
							if (ler_c == procura)
							{
								check = 200; //passa de zero para 1, o q prova que existe um numero igual
							}
							else
							{
								check = 0;	//não é igual
							}
						}
					}
					if ()
					{
						cout << "\n\nEsse numero de telefone existe nos contactos\n\n";
					}
			}
			else if(y == '2')
			{
			}
			else if(y == '3')
			{
			}
			else
			{
				contacts();
			}
	}
	else if (x == '0')
	{
		menu_principal();   //volta ao inicio
	}
	else
	{
		contacts(); //volta atras
	}
}
//________________________Encypt
void encriptar()
{
	string encri;	//MUDAR PARA STRING
	int h = 0, i, size, ascii=0;
	char x;
	system("CLS");
	cout << "1- Encryptar frase     ||    2- Desencryptar frase   (que foi encryptada por este encryptador)   || 0- Voltar ao menu inicial" << endl;
	cin >> x;
	if (x == '1')
	{
		cout << "Insira a mensagem que deseja encriptar: (* para sair)" << endl;
		getline(cin, encri, '*');
		while (h < 20 || h >1024)
		{
			cout << "Qual a chave para encriptar?   (entre 32 e 1024):" << endl;
			cin >> h;
		}
		size = sizeof(encri);
		for (i = 0; i <= size; i++)
		{
			ascii = (int)encri[i] + h;
			encri[i] = (char)ascii;
		}
		cout << "A mensagem encryptada:" << endl << encri ;
		cin.get(); cin.get();
		encriptar();
	}
	else if (x == '2')
	{
		cout << "Insira a mensagem que deseja desemcryptar: (* para sair)" << endl;
		getline(cin, encri, '*');
		while (h < 20 || h > 1024)
		{
			cout << "Qual a chave para desencryptar?   (entre 32 e 1024):" << endl;
			cin >> h;
		}
		size = sizeof(encri);
		for (i = 0; i <= size; i++)
		{
			ascii = (int)encri[i] - h;
			encri[i] = (char)ascii;
		}
		cout << "A mensagem desemcryptada:" << endl << encri;
		encriptar();
	}
	else if (x == '0')
	{
		menu_principal();   //volta ao inicio
	}
	else
	{
		encriptar();
	}
}
//________________________
//________________________
//________________________JOGOS
/*________________________BOTS
espaço de jogo vazio='0'
user='1'
bots='2'    els movem-se em direção ao user
______________________________________*/
void bots()
{
	system("CLS");
	int i = 0, j = 0, pontos = 0;
	char g1[50][50], sair, asdw; //game1 area de jogo
	cout << "Direcione para onde a sua personagem (*) deve ir, evite os '#'" << endl;
	cout << "Bem vindo ao jogo Bots, as teclas de jogo(seguido de enter):\nA|esquerda\nS|baixo\nD|direita\nW|cima\nT|teleport(so usar 6 vezes)" << endl;
	cout << "Carregue em enter para iniciar" << endl;
	cin.get();
	for (j = 0; j <= 49; j++)
	{
		for (i = 0; i <= 49; i++)
		{
			g1[i][j] = '0'; //inicia o campo vazio
		}
	}
	system("CLS");
	while (sair != '1')
	{
		pontos++;
		//teclas__________________________
		gotoxy(0, 70); //fora do alcance do jogo para decidir para onde ir
		cin >> asdw;
		asdw = toupper(asdw); //maiusculas
		if (asdw = 'A')
		{
		}
		else if (asdw = 'S')
		{
		}
		else if (asdw = 'D')
		{
		}
		else if (asdw = 'W')
		{
		}
		else if (asdw = 'T')
		{
		}
		//__________________________
		for (j = 0; j <= 49; j++) //y
		{
			for (i = 0; i <= 49; i++)	//x
			{
				if (g1[i][j] == '1' && g1[i + 1][j] == '2' || g1[i][j] == '1' && g1[i - 1][j] == '2' || g1[i][j] == '1' && g1[i][j + 1] == '2' || g1[i][j] == '1' && g1[i][j - 1] == '2')
				{
					system("CLS");
					cout << "Fim do jogo, you score is:" << pontos << endl;
				}
				else	//se o jogo não acabar, imprime
				{
					gotoxy(i, j);// vai á coordenada
					if (g1[i][j] = '0'){ cout << " "; }
					else if (g1[i][j] = '1'){ cout << "*"; }
					else if (g1[i][j] = '2'){ cout << "#"; }
					else{ cout << " "; } //torna o primeiro if inutil xD
				}
			}
		}
	}
}























